SAJU AI - BioSafe Agrovet (Starter Android Studio Project)

এই ZIP-টি একটি প্রাথমিক Android Studio source project।
APK সরাসরি এখানে তৈরি করা হয়নি।

খোলার নিয়ম:
1. Android Studio-তে Open নির্বাচন করুন।
2. ZIP extract করে SAJU_AI_BioSafe_Project ফোল্ডার নির্বাচন করুন।
3. Gradle Sync সম্পন্ন হতে দিন।
4. Build > Build APK(s) নির্বাচন করুন।

গুরুত্বপূর্ণ:
- এই starter সংস্করণে তথ্য SharedPreferences-এ ফোনে সংরক্ষিত হয়।
- এটি পূর্ণাঙ্গ Room database সংস্করণ নয়।
- লাইভ Gemini AI নেই।
- BioSafe-এর অফিসিয়াল পণ্যের নাম, দাম, প্যাক সাইজ বা মাত্রা ইচ্ছামতো যোগ করা হয়নি।
- অফিসিয়াল Excel/PDF ডেটা যুক্ত না করা পর্যন্ত নমুনা অ্যাপকে ব্যবসায়িক হিসাব বা কৃষি মাত্রার চূড়ান্ত উৎস হিসেবে ব্যবহার করবেন না।
- Gradle build-এর জন্য Android Studio ও JDK 17 প্রয়োজন।
