package com.example.sajuai

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray

private val Forest = Color(0xFF14532D)
private val Pale = Color(0xFFF1F8F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SajuApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SajuApp(context: Context) {
    val prefs = remember { context.getSharedPreferences("saju_data", Context.MODE_PRIVATE) }
    var tab by remember { mutableStateOf("হোম") }
    var products by remember { mutableStateOf(loadList(prefs, "products")) }
    var dealers by remember { mutableStateOf(loadList(prefs, "dealers")) }
    var sales by remember { mutableStateOf(loadList(prefs, "sales")) }
    var collections by remember { mutableStateOf(loadList(prefs, "collections")) }
    var tasks by remember { mutableStateOf(loadList(prefs, "tasks")) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Color(0xFF558B2F), background = Pale)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("SAJU AI", fontWeight = FontWeight.Bold)
                        Text("BioSafe Agrovet", style = MaterialTheme.typography.labelSmall)
                    } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Forest, titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("হোম", "পণ্য", "ফসল", "ডিলার", "হিসাব", "সহায়ক").forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { tab = item },
                            icon = { Icon(
                                when(item) {
                                    "হোম" -> Icons.Default.Home
                                    "পণ্য" -> Icons.Default.Inventory
                                    "ফসল" -> Icons.Default.Eco
                                    "ডিলার" -> Icons.Default.People
                                    "হিসাব" -> Icons.Default.Payments
                                    else -> Icons.Default.Chat
                                }, contentDescription = item
                            ) },
                            label = { Text(item) }
                        )
                    }
                }
            },
            containerColor = Pale
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when(tab) {
                    "হোম" -> HomePage(products.size, dealers.size, sales.size, tasks.size) { tab = it }
                    "পণ্য" -> DataPage("BioSafe পণ্য", products, "পণ্যের নাম / প্যাক সাইজ লিখুন") { value ->
                        products = products + value; saveList(prefs, "products", products)
                    }
                    "ফসল" -> CropPage()
                    "ডিলার" -> DataPage("ডিলার / রিটেইলার", dealers, "দোকান ও মালিকের নাম লিখুন") { value ->
                        dealers = dealers + value; saveList(prefs, "dealers", dealers)
                    }
                    "হিসাব" -> AccountsPage(sales, collections,
                        addSale = { sales = sales + it; saveList(prefs, "sales", sales) },
                        addCollection = { collections = collections + it; saveList(prefs, "collections", collections) })
                    else -> AssistantPage(tasks, { tasks = tasks + it; saveList(prefs, "tasks", tasks) })
                }
            }
        }
    }
}

@Composable
fun HomePage(productCount: Int, dealerCount: Int, saleCount: Int, taskCount: Int, navigate: (String)->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Forest), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text("আসসালামু আলাইকুম!", color = Color.White, style = MaterialTheme.typography.titleLarge)
                    Text("আপনার BioSafe কাজের ব্যক্তিগত সহায়ক", color = Color.White)
                    Spacer(Modifier.height(14.dp))
                    Text("পণ্য: $productCount   ডিলার: $dealerCount", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("বিক্রয় এন্ট্রি: $saleCount   বাকি কাজ: $taskCount", color = Color.White)
                }
            }
        }
        item { Text("দ্রুত কাজ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        items(listOf("পণ্য","ফসল","ডিলার","হিসাব","সহায়ক")) { label ->
            Card(onClick = { navigate(label) }, modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, modifier = Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                    Icon(Icons.Default.ChevronRight, contentDescription = null)
                }
            }
        }
        item {
            Text("দ্রষ্টব্য: অফিসিয়াল BioSafe মূল্য ও মাত্রার তালিকা যোগ না করা পর্যন্ত এখানে নমুনা তথ্য ব্যবহার করবেন না।",
                color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun DataPage(title: String, data: List<String>, hint: String, onAdd: (String)->Unit) {
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.fillMaxWidth(), label = { Text(hint) })
        Button(onClick = { if(input.isNotBlank()) { onAdd(input.trim()); input = "" } }, modifier = Modifier.fillMaxWidth()) { Text("যোগ করুন") }
        Spacer(Modifier.height(12.dp))
        if(data.isEmpty()) Text("এখনো কোনো তথ্য যোগ করা হয়নি।")
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(data) { entry -> Card(Modifier.fillMaxWidth()) { Text(entry, Modifier.padding(14.dp)) } }
        }
    }
}

@Composable
fun CropPage() {
    var crop by remember { mutableStateOf("") }
    var pest by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("ফসল ও বালাই অনুসন্ধান", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(crop, { crop = it }, Modifier.fillMaxWidth(), label = { Text("ফসলের নাম") })
        OutlinedTextField(pest, { pest = it }, Modifier.fillMaxWidth(), label = { Text("পোকা / রোগের নাম") })
        Spacer(Modifier.height(12.dp))
        Text("পরামর্শ: পোকা বা রোগ নিশ্চিতভাবে শনাক্ত করে অনুমোদিত লেবেল অনুযায়ী ব্যবস্থা নিন। সঠিক পণ্য ও মাত্রা জানতে BioSafe-এর অফিসিয়াল লেবেল/তালিকা ব্যবহার করুন।")
        Text("এই সংস্করণে কোনো অনুমোদিত মাত্রা বা কীটনাশক সুপারিশ বানিয়ে দেখানো হয় না।", color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun AccountsPage(sales: List<String>, collections: List<String>, addSale: (String)->Unit, addCollection: (String)->Unit) {
    var sale by remember { mutableStateOf("") }
    var collection by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("বিক্রয় ও কালেকশন", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(sale, { sale = it }, Modifier.fillMaxWidth(), label = { Text("বিক্রয় বিবরণ / টাকা") }) }
        item { Button(onClick = { if(sale.isNotBlank()) { addSale(sale); sale = "" } }, Modifier.fillMaxWidth()) { Text("বিক্রয় যোগ করুন") } }
        item { OutlinedTextField(collection, { collection = it }, Modifier.fillMaxWidth(), label = { Text("কালেকশন বিবরণ / টাকা") }) }
        item { Button(onClick = { if(collection.isNotBlank()) { addCollection(collection); collection = "" } }, Modifier.fillMaxWidth()) { Text("কালেকশন যোগ করুন") } }
        item { Text("বিক্রয় তালিকা", style = MaterialTheme.typography.titleMedium) }
        items(sales) { Text("• $it") }
        item { Text("কালেকশন তালিকা", style = MaterialTheme.typography.titleMedium) }
        items(collections) { Text("• $it") }
    }
}

@Composable
fun AssistantPage(tasks: List<String>, addTask: (String)->Unit) {
    var task by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("ব্যক্তিগত সহায়ক", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        OutlinedTextField(task, { task = it }, Modifier.fillMaxWidth(), label = { Text("নতুন কাজ / রিমাইন্ডার") })
        Button(onClick = { if(task.isNotBlank()) { addTask(task); task = "" } }, Modifier.fillMaxWidth()) { Text("কাজ যোগ করুন") }
        Spacer(Modifier.height(10.dp))
        tasks.forEach { Text("• $it") }
        HorizontalDivider(Modifier.padding(vertical = 12.dp))
        Text("অফলাইন সহায়ক", fontWeight = FontWeight.Bold)
        OutlinedTextField(question, { question = it }, Modifier.fillMaxWidth(), label = { Text("আপনার প্রশ্ন লিখুন") })
        Text("এই সংস্করণে লাইভ Gemini সংযুক্ত নেই। প্রশ্নের উত্তর দিতে যাচাইকৃত পণ্য/কৃষি তথ্যের ডেটাবেস ও AI সংযোগ পরবর্তী ধাপে যোগ করতে হবে।")
    }
}

private fun loadList(prefs: android.content.SharedPreferences, key: String): List<String> {
    val array = JSONArray(prefs.getString(key, "[]") ?: "[]")
    return (0 until array.length()).map { array.optString(it) }
}
private fun saveList(prefs: android.content.SharedPreferences, key: String, list: List<String>) {
    val array = JSONArray()
    list.forEach { array.put(it) }
    prefs.edit().putString(key, array.toString()).apply()
}
